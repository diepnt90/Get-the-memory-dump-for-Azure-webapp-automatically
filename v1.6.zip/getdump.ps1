$domain = $env:APPSETTING_WEBSITE_SITE_NAME
$password_prod = 'bsWdMQ2s9p6dY5WbYlljkNuBhufB6xREvGpd7tLSxd1dK2sqGlxCuQJMk1x6'
$blobintekey = 'ezmUZH5z8Sfp7ik0qXmwkbKjxaqxws6CGyBLNufHjSJZOMB9hiW1zzV/QjaRFdaqkWXUkh/NuHdy3VHbnv0dnw=='
$pair_prod = "`$$($domain):$password_prod"
$Bytes_prod = [System.Text.Encoding]::UTF8.GetBytes($pair_prod)
$Encoded_prod = [System.Convert]::ToBase64String($Bytes_prod)
$basicAuthValue_prod = "Basic $Encoded_prod"
$headers_prod = @{ Authorization = $basicAuthValue_prod}
$instanceId = $env:WEBSITE_INSTANCE_ID
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$cookie = New-Object System.Net.Cookie 
$cookie.Name = "ARRAffinity"
$cookie.Value = $instanceId
$cookie.Domain = "$domain.scm.azurewebsites.net"
$session.Cookies.Add($cookie)
$response = Invoke-RestMethod -Uri "https://$domain.scm.azurewebsites.net/api/processes/-1" -Method GET -Headers $headers_prod -ContentType "application/json" -WebSession $session
$processid = $response.id
New-Item -Path 'D:\local\Temp\dumps' -ItemType Directory
New-Item -Path 'D:\local\Temp\azcopy' -ItemType Directory
$command="d:\devtools\sysinternals\procdump -accepteula -ma $processid -m 300 -s 5 -n 1 D:\local\Temp\dumps";
iex $command
stop-process -id $processid
$EnvironmentName = $domain.Substring($domain.Length - 4, 4)
$ProjectName = $domain.Substring(0, $domain.Length - 4)
if ($EnvironmentName -eq 'prod') {$InteWebApp = "$($ProjectName)inte"}
D:\home\site\wwwroot\App_Data\jobs\continuous\getdump\AzCopy\AzCopy.exe /Source:D:\local\Temp\dumps /Dest:https://$InteWebApp.blob.core.windows.net/memorydumps /DestKey:$blobintekey /Y /S /Z:D:\local\Temp\azcopy
Start-Sleep -s 600
Remove-Item 'D:\local\Temp\dumps' -Recurse
Remove-Item 'D:\local\Temp\azcopy' -Recurse
Invoke-RestMethod -uri "https://$domain.scm.azurewebsites.net/api/continuouswebjobs/getdump/stop" -Method POST -Headers $headers_prod -ContentType "application/json"